<?php
//Alyssa Tyler Jimenez
//I certify that this submission is my own original work.
//Dated May 8th, 2023


   $username = $password = $email = $confirmpassword = "";
  
  //check if input posted
      if (isset($_POST['username']))
        $username = fix_string($_POST['username']);
        
      if (isset($_POST['password']))
        $password = fix_string($_POST['password']);
        
      if (isset($_POST['email']))
        $email    = fix_string($_POST['email']);
        
      if (isset($_POST['confirmpassword']))
        $confirmpassword = fix_string($_POST['confirmpassword']);


      $fail = validate_username($username);
      $fail .= validate_password($password);
      $fail .= validate_email($email);
      $fail .= validate_confirm($password, $confirmpassword);

      echo "<!DOCTYPE html><html><title>Capstone Project - Alyssa Jimenez</title>";

      if ($fail == "")
      {
        echo "</head><body>Form data successfully validated:
           $username, $password, $email.</body></html>";

            exit;
      }

      echo <<<_END

        <!-- The HTML/JavaScript section -->

        <head>
        <title>Music Record Login Page</title>
        <link rel="stylesheet" href="musicrecordsstyles.css">
        <script src="mr_validationscript.js"></script>
        </head>
        <body>
        
        <h1>Music Record Registration</h1>
        <form method="post" action="register_users.php" onsubmit="return validate(this)">
            <label for="Username">Username:<br></label>
            <input type="text" name="username" size="10" value="" required><br>

            <br>

            <label for="Email">Email:<br></label>
            <input type="text" name="email" size="10" value="" required><br>

            <br>

            <label for="Password">Password:<br></label>
            <input type="text" name="password" size="10" value="" required><br>
            <br>

            <label for="Confirm Password">Confirm Password:<br></label>
            <input type="text" name="confirmpassword" size="10" value="" required><br>

            <br>

            <br>
            <input type="submit" value="Register">
        </form>
        <p><a href='login_page.php'>Returning User? Login here!</a></p>
        </body>
        </html>


_END;

      // The PHP functions
      
    function validate_username($field)
    {
        if ($field == "") return "No Username was entered<br>";
        else if (strlen($field) < 5)
            return "Usernames must be at least 5 characters<br>";
        else if (preg_match("/[^a-zA-Z0-9_-]/", $field))
    return "Only letters, numbers, - and _ in usernames<br>";
        return "";		
    }
      
    function validate_password($field)
    {
        if ($field == "") return "No Password was entered<br>";
        else if (strlen($field) < 6)
            return "Passwords must be at least 6 characters<br>";
        else if (!preg_match("/[a-z]/", $field) ||
                 !preg_match("/[A-Z]/", $field) ||
                 !preg_match("/[0-9]/", $field))
            return "Passwords require 1 each of a-z, A-Z and 0-9<br>";
        return "";
    }
      
      
    function validate_email($field)
    {
        if ($field == "") return "No Email was entered<br>";
        else if (!((strpos($field, ".") > 0) &&
                    (strpos($field, "@") > 0)) ||
                    preg_match("/[^a-zA-Z0-9.@_-]/", $field))
            return "The Email address is invalid<br>";
        return "";
    }
    
    function validate_confirm($field, $field2)
    {
        if ($field == "") return "Password Confirmation was not Entered<br>";
        else if ($field != $field2)
            return "The Passwords do not Match.<br>";
        return "";
    }
      
    function fix_string($string)
    {
        if (get_magic_quotes_gpc()) $string = stripslashes($string);
        return htmlentities ($string);
    }
?>
