<?php
//Alyssa Tyler Jimenez
//I certify that this submission is my own original work.
//Dated May 8th, 2023

    session_start();

    // Check if the user is logged in
    if (isset($_SESSION['username'])) {
      $username = $_SESSION['username'];
      // Display the logout link
      echo "<p>Welcome, $username! <a href='logout.php'>Logout</a></p>";
    } else {
      // Redirect to the login page if the user is not logged in
      header("Location: login_page.php");
      exit;
    }
    
    $server = 'localhost';
    $username = 'bcs350sp23';
    $password = 'passwdsp23';
    $db = 'MusicRecords';
    $conn = new mysqli($server, $username, $password, $db);
    
    if($conn->connect_error)
        die("Fatal Error: Login");
    
    echo "<h1>Delete Records</h1> <br>";
    
    $query  = "SELECT * FROM records";
    $result = $conn->query($query);
    if (!$result) die ("Database access failed");

    $rows = $result->num_rows;

    for ($j = 0 ; $j < $rows ; ++$j)
    {
        $row = $result->fetch_array(MYSQLI_NUM);
        $r0 = htmlspecialchars($row[0]);
        $r1 = htmlspecialchars($row[1]);
        $r2 = htmlspecialchars($row[2]);
        $r3 = htmlspecialchars($row[3]);
        $r4 = htmlspecialchars($row[4]);
        $r5 = htmlspecialchars($row[5]);
        
    echo <<<_END
          <pre>
            AlbumID $r0
            Album $r1
            Artist$r2
              Year $r3
              Genre $r4
            Number of Songs $r5
          </pre>
          <form action='deleterecord.php' method='post'>
          <input type='hidden' name='delete' value='yes'>
          <input type='hidden' name='albumid' value='$r0'>
          <input type='submit' value='DELETE RECORD'></form>
_END;
    }
    
    if (isset($_POST['delete']) && isset($_POST['albumid']))
  {
    $albumid = $_POST['albumid'];
    $query  = "DELETE FROM records WHERE albumid='$albumid'";
    $result = $conn->query($query);
    echo "<h1>DELETE SUCCESSFUL.<br>";
    if (!$result) echo "DELETE failed<br><br>";
  }
    
  $conn->close();
  echo "<p><a href='functions_main.php'>Back to Homepage.</a></p>";

echo <<<_END

<!DOCTYPE html>
<html>
<head>
  <title>Music Record Add Record</title>
  <link rel="stylesheet" href="musicrecordsstyles.css">
</head>
<body>



_END

?>