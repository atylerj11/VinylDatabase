<?php
//Alyssa Tyler Jimenez
//I certify that this submission is my own original work.
//Dated May 8th, 2023


echo <<<_END

<!DOCTYPE html>
<html>
<head>
  <title>Music Record Login Page</title>
  <link rel="stylesheet" href="musicrecordsstyles.css">
  <script src="mr_validationscript.js"></script>
</head>
<body>

  <h1>Music Records Database Login <img src="pink_record.gif" align="right" alt="Pink Record"></h1>
  <img src="ribbon_heart.gif" align="center" alt="Divider">
  <br>
  <form method="post" action="user_login_check.php" onsubmit="return validate(this)">
    <label for="username">Username:</label>
    <input type="text" id="username" name="username" required><br><br>
    <label for="password">Password:</label>
    <input type="password" id="password" name="password" required><br><br>
    <input type="submit" value="Login">
  </form>
  <img src="ribbon_heart.gif" align="center" alt="Divider">
  
  <p><a href='registration_page.html'>New User? Register here!</a></p>
</body>
</html>


_END
?>