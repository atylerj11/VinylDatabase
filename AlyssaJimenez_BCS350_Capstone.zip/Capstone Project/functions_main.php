<?php
//Alyssa Tyler Jimenez
//I certify that this submission is my own original work.
//Dated May 8th, 2023


    session_start();

    // Check if the user is logged in
    if (isset($_SESSION['username'])) {
      $username = $_SESSION['username'];
      // Display the logout link
      echo "<p>Welcome, $username! <a href='logout.php'>Logout</a></p>";
    } else {
      // Redirect to the login page if the user is not logged in
      header("Location: login_page.php");
      exit;
    }

echo <<<_END

<html>
<head>
    <title>Capstone Project - Alyssa Jimenez</title>
    <link rel="stylesheet" href="musicrecordsstyles.css">
</head>

    <h1>Main Functions</h1>
    
    <h4>Add Record</h4>
    <form action="addrecord.php" method="post"><pre>
    If no Genre, put NULL. 
    If no Album/Artist/Genre put Unknown. 
    If Number of Songs or Year unknown, put 0.
              Album <input type="text" name="album">
             Artist <input type="text" name="artist">
               Year <input type="text" name="year">
              Genre <input type="text" name="genre">
    Number of Songs <input type="text" name="numberofsongs">
                   <input type="submit" value="ADD RECORD">
    </pre>
    </form>
    
    <h4>Delete Record</h4>
    <form action="deleterecord.php" method="post"><pre>
    <input type="submit" value="DELETE RECORD LINK">
    </pre>
    </form>

    <h4>Search Records</h4>
    <form method="post" action="searchrecord.php">

    <label for="field">Select a field to search in:<br></label>
    <select name="field" size="1">
    <option value ="albumid">AlbumID</options>
    <option value ="album">Album</options>
    <option value ="artist">Artist</options>
    <option value ="year">Year</options>
    <option value ="genre">Genre</options>
    <option value ="numberofsongs">NumberOfSongs</options>
    </select><br>
    
    <br>
    
    <label for="value">Enter a value to search for:<br></label>
    <input type="text" name="value" id="value">
    <br>
     
    <br>                    
    <input type="submit" value="SEARCH RECORD">
    </pre>
    </form>
    
    <h4>List Records</h4>
    <form action="listrecords.php" method="post"><pre>
    <input type="submit" value="LIST RECORD LINK">
    </pre>
    </form>
    
    <form action="logout.php" method="post">
        <input type="submit" value="Logout">
    </form>

</body>
</html>

_END

?>