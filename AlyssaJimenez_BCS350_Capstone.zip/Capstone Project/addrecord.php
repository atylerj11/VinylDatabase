<?php
//Alyssa Tyler Jimenez
//I certify that this submission is my own original work.
//Dated May 8th, 2023


    session_start();

    // Check if the user is logged in
    if (isset($_SESSION['username'])) {
      $username = $_SESSION['username'];
      // Display the logout link
      echo "<p>Welcome, $username! <a href='logout.php'>Logout</a></p>";
    } else {
      // Redirect to the login page if the user is not logged in
      header("Location: login_page.php");
      exit;
    }
    
    $server = 'localhost';
    $username = 'bcs350sp23';
    $password = 'passwdsp23';
    $db = 'MusicRecords';
    $conn = new mysqli($server, $username, $password, $db);
    
    if($conn->connect_error)
        die("Fatal Error: Login");

    echo "<h1>Add Records</h1> <br>";
    
    if (isset($_POST['album'])   &&
      isset($_POST['artist'])    &&
      isset($_POST['year']) &&
      isset($_POST['genre'])     &&
      isset($_POST['numberofsongs'])){
          
        $album = $_POST['album'];
        echo "$album <br>";
        
        $artist = $_POST['artist'];
        echo "$artist <br>";
        
        $year = $_POST['year'];
        echo "$year <br>";
        
        $genre = $_POST['genre'];
        echo "$genre <br>";
        
        $numberofsongs= $_POST['numberofsongs'];
        echo "$numberofsongs <br>";
        
        $query    = "INSERT INTO records VALUES(NULL, '$album', '$artist', $year, '$genre', $numberofsongs)";
        $result   = $conn->query($query);
        if (!$result) echo "INSERT failed<br><br>";
  }
  
  echo "<p><a href='functions_main.php'>Back to Homepage.</a></p>";
  
echo <<<_END

<!DOCTYPE html>
<html>
<head>
  <title>Music Record Add Record</title>
  <link rel="stylesheet" href="musicrecordsstyles.css">
</head>
<body>



_END
    

?>