<?php
//Alyssa Tyler Jimenez
//I certify that this submission is my own original work.
//Dated May 8th, 2023


    session_start();

    // Check if the user is logged in
    if (isset($_SESSION['username'])) {
      $username = $_SESSION['username'];
      // Display the logout link
      echo "<p>Welcome, $username! <a href='logout.php'>Logout</a></p>";
    } else {
      // Redirect to the login page if the user is not logged in
      header("Location: login_page.php");
      exit;
    }
    
    $server = 'localhost';
    $username = 'bcs350sp23';
    $password = 'passwdsp23';
    $db = 'MusicRecords';
    $conn = new mysqli($server, $username, $password, $db);
    
    if($conn->connect_error)
        die("Fatal Error: Login");
        
    echo "<h1>Listing Current Records</h1> <br>";
    
    $query  = "SELECT * FROM records";
    $result = $conn->query($query);
    if (!$result) die ("Database access failed");

    $rows = $result->num_rows;
    echo "<table><tr> <th>AlbumID</th> <th>Album</th><th>Artist</th><th>Year</th><th>Genre</th><th>Number of Songs</th></tr>";

    for ($j = 0 ; $j < $rows ; ++$j)
    {
        $result->data_seek($j);
            $row = $result->fetch_array(MYSQLI_NUM);

            echo "<tr>";
        for ($k = 0 ; $k < 6 ; ++$k)
        echo "<td>" . htmlspecialchars($row[$k]) . "</td>";
            echo "</tr>";
    }

    echo "</table>";
    echo "<p><a href='functions_main.php'>Back to Homepage.</a></p>";
    
echo <<<_END

<!DOCTYPE html>
<html>
<head>
  <title>Music Record Add Record</title>
  <link rel="stylesheet" href="musicrecordsstyles.css">
</head>
<body>



_END
?>