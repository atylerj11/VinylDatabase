<?php
//Alyssa Tyler Jimenez
//I certify that this submission is my own original work.
//Dated May 8th, 2023


    $server = 'localhost';
    $username = 'bcs350sp23';
    $password = 'passwdsp23';
    $db = 'MusicRecords';
    $conn = new mysqli($server, $username, $password, $db);
        
    if($conn->connect_error)
        die("Fatal Error: Database Connection");
        
    if(isset($_POST['username']))  //checking if posted
       $username = $_POST['username'];
   
    if(isset($_POST['password']))    
       $password = $_POST['password'];
    
    //check if 
    $query = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $query->bind_param("s", $username);
    $query->execute();
    $resultuser = $query->get_result();
    
    if (!$resultuser){
        die("Fatal Error: " . $conn->error);
    }
    
    if ($resultuser->num_rows > 0){
        $row = $resultuser->fetch_array(MYSQLI_NUM);
        
        if (password_verify($password, $row[1])){ //checking HASHED password
            session_start();

            $_SESSION['username'] = $row[0];
            $_SESSION['password']  = $row[1];
            echo htmlspecialchars("$row[0] : Hi $row[0], you are now logged in. ");
            echo "<a href='logout.php'>Logout</a>";
        }else{
            die("<p><a href='login_page.php'>Invalid username/password combination. Click here to go back. </a></p>");
        }

    }else{
        die("<p><a href='login_page.php'>Invalid username/password combination. Click here to go back.</a></p>");
    }
?>

<html>
<head>
    <title>Capstone Project - Alyssa Jimenez</title>
    <link rel="stylesheet" href="musicrecordsstyles.css">
</head>

    <h1>Main Functions</h1>
    
    <h4>Add Record</h4>
    <form action="addrecord.php" method="post"><pre>
    If no Genre, put NULL. 
    If no Album/Artist/Genre put Unknown. 
    If Number of Songs or Year unknown, put 0.
              Album <input type="text" name="album">
             Artist <input type="text" name="artist">
               Year <input type="text" name="year">
              Genre <input type="text" name="genre">
    Number of Songs <input type="text" name="numberofsongs">
                   <input type="submit" value="ADD RECORD">
    </pre>
    </form>
    
    <h4>Delete Record</h4>
    <form action="deleterecord.php" method="post"><pre>
    <input type="submit" value="DELETE RECORD LINK">
    </pre>
    </form>

    <h4>Search Records</h4>
    <form method="post" action="searchrecord.php">

    <label for="field">Select a field to search in:<br></label>
    <select name="field" size="1">
    <option value ="albumid">AlbumID</options>
    <option value ="album">Album</options>
    <option value ="artist">Artist</options>
    <option value ="year">Year</options>
    <option value ="genre">Genre</options>
    <option value ="numberofsongs">NumberOfSongs</options>
    </select><br>
    
    <br>
    
    <label for="value">Enter a value to search for:<br></label>
    <input type="text" name="value" id="value">
    <br>
     
    <br>                    
    <input type="submit" value="SEARCH RECORD">
    </pre>
    </form>
    
    <h4>List Records</h4>
    <form action="listrecords.php" method="post"><pre>
    <input type="submit" value="LIST RECORD LINK">
    </pre>
    </form>
    

</body>
</html>
