<?php
//Alyssa Tyler Jimenez
//I certify that this submission is my own original work.
//Dated May 8th, 2023

    $server = 'localhost';
    $username = 'bcs350sp23';
    $password = 'passwdsp23';
    $db = 'MusicRecords';
    $conn = new mysqli($server, $username, $password, $db);
        
    if($conn->connect_error)
        die("Fatal Error: Database Connection");
        
    if(isset($_POST['username']))  //checking if posted
       $username = $_POST['username'];
       
    if(isset($_POST['email']))    
       $email = $_POST['email'];
   
    if(isset($_POST['password']))    
       $password = $_POST['password'];

    if(isset($_POST['confirmpassword']))    
       $confirm = $_POST['confirmpassword'];
    
    $hash     = password_hash($password, PASSWORD_DEFAULT);
       
       
    if($password != $confirm){
        echo "<p>Password Does Not Match, Please return to previous page.</p>";
    }else{
        
      
        $query = "INSERT INTO Users (Username, Password, Email) VALUES ('$username', '$hash', '$email')";

        if (mysqli_query($conn, $query)) {
            echo "New record created successfully";
            echo "<p><a href='login_page.php'>Click here to Log In.</a></p>";
        } else {
            echo "Error: <br>" . mysqli_error($conn);
        }

        mysqli_close($conn);
            
    }
    
    echo <<<_END

<!DOCTYPE html>
<html>
<head>
  <title>Music Record Add Record</title>
  <link rel="stylesheet" href="musicrecordsstyles.css">
</head>
<body>



_END
    
?>