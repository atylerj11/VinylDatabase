<?php
//Alyssa Tyler Jimenez
//I certify that this submission is my own original work.
//Dated May 8th, 2023


    session_start();
    session_unset();
    session_destroy();
    header("Location: login_page.php");
    exit;
?>