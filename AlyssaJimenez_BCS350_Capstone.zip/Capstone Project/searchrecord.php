<?php
//Alyssa Tyler Jimenez
//I certify that this submission is my own original work.
//Dated May 8th, 2023

    session_start();

    // Check if the user is logged in
    if (isset($_SESSION['username'])) {
      $username = $_SESSION['username'];
      // Display the logout link
      echo "<p>Welcome, $username! <a href='logout.php'>Logout</a></p>";
    } else {
      // Redirect to the login page if the user is not logged in
      header("Location: login_page.php");
      exit;
    }

    $server = 'localhost';
    $username = 'bcs350sp23';
    $password = 'passwdsp23';
    $db = 'MusicRecords';
    $conn = new mysqli($server, $username, $password, $db);
    
    if($conn->connect_error)
        die("Fatal Error: Login");
    
    /* get information from form */
    if(isset($_POST['field']))  //checking if posted
       $field = $_POST['field'];
   
    if(isset($_POST['value']))    
       $value = $_POST['value'];
       
    echo "<h2>Search Record Result</h2><br>";
    
    $query = "SELECT * FROM records WHERE $field LIKE '%$value%'";
    $result = $conn->query($query);
    if (!$result) 
        die("Fatal Error: Result");

    $rows = $result->num_rows;
    
    /* if there are no results */
    if ($rows == 0){
        echo "<p>No record was found.</p>";
        echo "<p><a href='functions_main.php'>Go back to retry.</a></p>";
    }else{
        $rows = $result->num_rows;

            $row = $result->fetch_array(MYSQLI_NUM);
            $r0 = htmlspecialchars($row[0]);
            $r1 = htmlspecialchars($row[1]);
            $r2 = htmlspecialchars($row[2]);
            $r3 = htmlspecialchars($row[3]);
            $r4 = htmlspecialchars($row[4]);
            $r5 = htmlspecialchars($row[5]);
            
            echo <<<_END
                <B>AlbumID</B> $r0 <br>
                <B>Album</B> $r1 <br>
                <B>Artist</B> $r2 <br>
                <B>Year</B> $r3 <br>
                <B>Genre</B> $r4 <br>
                <B>Number of Songs</B> $r5 <br>
_END;

    echo "<p><a href='functions_main.php'>Back to Homepage.</a></p>";
    }

    echo "</table>";
    
    /* close connections */
    $result->close();
    $conn->close();


echo <<<_END

<!DOCTYPE html>
<html>
<head>
  <title>Music Record Add Record</title>
  <link rel="stylesheet" href="musicrecordsstyles.css">
</head>
<body>



_END

?>