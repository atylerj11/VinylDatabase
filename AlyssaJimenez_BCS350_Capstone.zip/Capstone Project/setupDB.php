<?php
//Alyssa Tyler Jimenez
//I certify that this submission is my own original work.
//Dated May 8th, 2023

    $server = 'localhost';
    $username = 'bcs350sp23';
    $password = 'passwdsp23';
    $db = 'MusicRecords';
    $conn = new mysqli($server, $username, $password, $db);
    
    if($conn->connect_error)
        die("Fatal Error: Database Connection");
        
    $query = "CREATE TABLE if not exists Records(
    AlbumID SMALLINT NOT NULL AUTO_INCREMENT,
    Album VARCHAR(255) NOT NULL,
    Artist VARCHAR(32) NOT NULL,
    Year SMALLINT NOT NULL,
    Genre VARCHAR(32),
    NumberOfSongs SMALLINT NOT NULL,
    PRIMARY KEY (AlbumID)
  );";

    $result = $conn->query($query);
    if (!$result) die ("Database Table Creation failed");
  
    $query  = "INSERT INTO Records VALUES(NULL, 'Meant To Be Mint', 'Mint Condition', '1991', 'R&B', 12)";
    $result = $conn->query($query);
    if (!$result) die ("Database Insert 1 failed");
  
    $query  = "INSERT INTO Records VALUES(NULL, 'Never Say Never', 'Brandy', '1998', 'R&B', 16)";
    $result = $conn->query($query);
    if (!$result) die ("Database Insert 2 failed");
  
    $query  = "INSERT INTO Records VALUES(NULL, '2 Different Tears', 'Wonder Girls', '2010', 'KPOP', 11)";
    $result = $conn->query($query);
    if (!$result) die ("Database Insert 3 failed");
  
    $query  = "INSERT INTO Records VALUES(NULL, 'Electra Heart (Deluxe)', 'MARINA', '2012', 'Pop', 17)";
    $result = $conn->query($query);
    if (!$result) die ("Database Insert 4 failed");
  
    $query  = "INSERT INTO Records VALUES(NULL, 'AM', 'Arctic Monkeys', '2013', 'Indie Rock', 12)";
    $result = $conn->query($query);
    if (!$result) die ("Database Insert 5 failed");
  
    $query  = "INSERT INTO Records VALUES(NULL, 'Blurryface', 'Twenty One Pilots', '2015', 'Alternative Rock', 14)";
    $result = $conn->query($query);
    if (!$result) die ("Database Insert 6 failed");
  
    $query  = "INSERT INTO Records VALUES(NULL, 'Cry Baby', 'Melanie Martinez', '2015', 'Alternative/Indie', 16)";
    $result = $conn->query($query);
    if (!$result) die ("Database Insert 7 failed");
  
    $query  = "INSERT INTO Records VALUES(NULL, 'LOVE YOURSELF 結 Answer', 'BTS', '2018', 'KPOP', 26)";
    $result = $conn->query($query);
    if (!$result) die ("Database Insert 8 failed");
  
    $query  = "INSERT INTO Records VALUES(NULL, 'PURE', 'Cö shu Nie', '2019', 'Alternative J Rock', 12)";
    $result = $conn->query($query);
    if (!$result) die ("Database Insert 9 failed");
  
    $query  = "INSERT INTO Records VALUES(NULL, 'Girl in the Space Room', 'snooty', '2022', 'JPOP', 1)";
    $result = $conn->query($query);
    if (!$result) die ("Database Insert 10 failed");
    
    $query = "CREATE TABLE if not exists Users(
    Username VARCHAR(255) NOT NULL UNIQUE,
    Password VARCHAR(255) NOT NULL,
    Email VARCHAR(255) NOT NULL,
    PRIMARY KEY (Username)
    );";

    $result = $conn->query($query);
    if (!$result) die ("Database User Table Creation failed");
    
    echo "Successfully Setup";

?>